package connection;


import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class javaconnect {
Connection conn = null;
public static Connection connecrjdbc(){
  try{
    Class.forName("com.mysql.jdbc.Driver");
     Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/faida", "root", "");
     System.out.println("Connected");
     return conn;
} catch (Exception e){
     JOptionPane.showMessageDialog(null, e);
      return null;
}
       
}
}